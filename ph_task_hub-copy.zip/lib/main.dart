import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:http/http.dart' as http;
import 'package:share_plus/share_plus.dart';
import 'dart:convert';
import 'dart:math';

class AppConfig {
  static const String appName = 'Amambo TaskHub';
  static const String bannerAd = 'ca-app-pub-5595332733826231/2706377702';
  static const String interAd = 'ca-app-pub-5595332733826231/4728478392';
  static const String vtuApiUrl = 'https://my-api-proxy-sigma.vercel.app/api/vtu';
  static const String paystackAds = 'https://paystack.shop/pay/amambotaskhub-ads';
  static const String paystackDeposit = 'https://paystack.shop/pay/xma52vyic0';
  static const int referralReward = 200;
  static const int welcomeReward = 100;
  static const String privacyUrl = 'https://amambotaskhub.com/privacy';
  static const String supportUrl = 'https://amambotaskhub.com/support';
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  } catch (e) {
    debugPrint("Firebase error: $e");
  }
  try {
    await MobileAds.instance.initialize();
  } catch (e) {
    debugPrint("Ads error: $e");
  }
  runApp(const AmamboTaskHubPro());
}

class AmamboTaskHubPro extends StatelessWidget {
  const AmamboTaskHubPro({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: AppConfig.appName,
      theme: ThemeData(
        primarySwatch: Colors.green,
        scaffoldBackgroundColor: const Color(0xFFF6FFF8),
        appBarTheme: const AppBarTheme(backgroundColor: Colors.green, foregroundColor: Colors.white, elevation: 0),
      ),
      home: const AuthGate(),
    );
  }
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});
  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (c, snap) {
        if (snap.connectionState == ConnectionState.waiting) {
          return const Scaffold(body: Center(child: CircularProgressIndicator(color: Colors.green)));
        }
        if (snap.hasData && snap.data!= null) return const MainNavPro();
        return const LoginPro();
      },
    );
  }
}

class LoginPro extends StatefulWidget {
  const LoginPro({super.key});
  @override
  State<LoginPro> createState() => _LoginProState();
}

class _LoginProState extends State<LoginPro> {
  final emailCtrl = TextEditingController();
  final passCtrl = TextEditingController();
  bool loadingNow = false;

  Future<void> doLogin() async {
    if (emailCtrl.text.trim().isEmpty || passCtrl.text.trim().isEmpty) return;
    setState(() => loadingNow = true);
    try {
      await FirebaseAuth.instance.signInWithEmailAndPassword(email: emailCtrl.text.trim(), password: passCtrl.text.trim());
    } on FirebaseAuthException catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message?? 'Login failed'), backgroundColor: Colors.red));
    }
    if (mounted) setState(() => loadingNow = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          const SizedBox(height: 60),
          const Icon(Icons.task_alt_rounded, size: 90, color: Colors.green),
          const SizedBox(height: 12),
          const Text('Amambo TaskHub', textAlign: TextAlign.center, style: TextStyle(fontSize: 32, fontWeight: FontWeight.w900, color: Colors.green)),
          const Text('V18 • Secure • Play Store Ready', textAlign: TextAlign.center, style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Colors.black54)),
          const SizedBox(height: 32),
          TextField(controller: emailCtrl, decoration: const InputDecoration(labelText: 'Email', border: OutlineInputBorder(), prefixIcon: Icon(Icons.email))),
          const SizedBox(height: 12),
          TextField(controller: passCtrl, obscureText: true, decoration: const InputDecoration(labelText: 'Password', border: OutlineInputBorder(), prefixIcon: Icon(Icons.lock))),
          const SizedBox(height: 20),
          ElevatedButton(
            style: ElevatedButton.styleFrom(minimumSize: const Size(double.infinity, 56), backgroundColor: Colors.green, foregroundColor: Colors.white),
            onPressed: loadingNow? null : doLogin,
            child: Text(loadingNow? 'PLEASE WAIT...' : 'LOGIN'),
          ),
          const SizedBox(height: 12),
          OutlinedButton(
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const RegisterPro())),
            child: const Text('CREATE FREE ACCOUNT - GET ₦100 BONUS'),
          ),
        ]),
      ),
    );
  }
}

class RegisterPro extends StatefulWidget {
  const RegisterPro({super.key});
  @override
  State<RegisterPro> createState() => _RegisterProState();
}

class _RegisterProState extends State<RegisterPro> {
  final nameCtrl = TextEditingController();
  final phoneCtrl = TextEditingController();
  final emailCtrl = TextEditingController();
  final passCtrl = TextEditingController();
  final referralCtrl = TextEditingController();
  bool creatingAccount = false;

  String generateReferralCode() {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    final rnd = Random.secure();
    return 'AM${List.generate(4, (_) => chars[rnd.nextInt(chars.length)]).join()}';
  }

  Future<void> createAccountPro() async {
    if (nameCtrl.text.trim().isEmpty || emailCtrl.text.trim().isEmpty || passCtrl.text.trim().length < 6) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Fill all fields, password min 6'), backgroundColor: Colors.red));
      return;
    }
    setState(() => creatingAccount = true);
    try {
      final cred = await FirebaseAuth.instance.createUserWithEmailAndPassword(email: emailCtrl.text.trim(), password: passCtrl.text.trim());
      final String myCode = generateReferralCode();
      final String inputCode = referralCtrl.text.trim().toUpperCase();
      String referredBy = '';
      String referrerUid = '';
      if (inputCode.isNotEmpty) {
        final query = await FirebaseFirestore.instance.collection('users').where('myReferralCode', isEqualTo: inputCode).limit(1).get();
        if (query.docs.isNotEmpty) {
          referredBy = inputCode;
          referrerUid = query.docs.first.id;
        }
      }
      int initialWallet = AppConfig.welcomeReward;
      if (referredBy.isNotEmpty) initialWallet += 50;
      await FirebaseFirestore.instance.collection('users').doc(cred.user!.uid).set({
        'name': nameCtrl.text.trim(),
        'email': emailCtrl.text.trim(),
        'phone': phoneCtrl.text.trim(),
        'wallet': initialWallet,
        'myReferralCode': myCode,
        'referredBy': referredBy,
        'referralsCount': 0,
        'referralEarnings': 0,
        'isActivated': true,
        'createdAt': FieldValue.serverTimestamp(),
      });
      if (referrerUid.isNotEmpty) {
        await FirebaseFirestore.instance.collection('users').doc(referrerUid).update({
          'wallet': FieldValue.increment(AppConfig.referralReward),
          'referralsCount': FieldValue.increment(1),
          'referralEarnings': FieldValue.increment(AppConfig.referralReward),
        });
      }
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Welcome! ₦$initialWallet bonus'), backgroundColor: Colors.green));
        Navigator.pop(context);
      }
    } on FirebaseAuthException catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message?? 'Failed'), backgroundColor: Colors.red));
    } finally {
      if (mounted) setState(() => creatingAccount = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Create Free Account V18')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(18),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(color: Colors.green.shade50, borderRadius: BorderRadius.circular(12)),
            child: const Text('FREE Registration • Get ₦100 bonus • Refer & Earn ₦200', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Colors.green)),
          ),
          const SizedBox(height: 14),
          TextField(controller: nameCtrl, decoration: const InputDecoration(labelText: 'Full Name', border: OutlineInputBorder())),
          const SizedBox(height: 10),
          TextField(controller: phoneCtrl, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'Phone 080...', border: OutlineInputBorder())),
          const SizedBox(height: 10),
          TextField(controller: emailCtrl, decoration: const InputDecoration(labelText: 'Email', border: OutlineInputBorder())),
          const SizedBox(height: 10),
          TextField(controller: passCtrl, obscureText: true, decoration: const InputDecoration(labelText: 'Password Min 6', border: OutlineInputBorder())),
          const SizedBox(height: 10),
          TextField(controller: referralCtrl, textCapitalization: TextCapitalization.characters, decoration: const InputDecoration(labelText: 'Referral Code Optional', border: OutlineInputBorder())),
          const SizedBox(height: 16),
          ElevatedButton(
            style: ElevatedButton.styleFrom(minimumSize: const Size(double.infinity, 54), backgroundColor: Colors.green, foregroundColor: Colors.white),
            onPressed: creatingAccount? null : createAccountPro,
            child: Text(creatingAccount? 'CREATING...' : 'CREATE FREE ACCOUNT'),
          ),
        ]),
      ),
    );
  }
}

class MainNavPro extends StatefulWidget {
  const MainNavPro({super.key});
  @override
  State<MainNavPro> createState() => _MainNavProState();
}

class _MainNavProState extends State<MainNavPro> {
  int selectedPage = 0;
  final List<Widget> pages = const [HomePro(), AdvertisePro(), VTUPro(), ProfilePro()];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: pages[selectedPage],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: selectedPage,
        onTap: (i) => setState(() => selectedPage = i),
        type: BottomNavigationBarType.fixed,
        selectedItemColor: Colors.green,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home_rounded), label: 'Earn'),
          BottomNavigationBarItem(icon: Icon(Icons.campaign_rounded), label: 'Ads'),
          BottomNavigationBarItem(icon: Icon(Icons.phone_android_rounded), label: 'VTU'),
          BottomNavigationBarItem(icon: Icon(Icons.wallet), label: 'Wallet'),
        ],
      ),
    );
  }
}

class HomePro extends StatefulWidget {
  const HomePro({super.key});
  @override
  State<HomePro> createState() => _HomeProState();
}

class _HomeProState extends State<HomePro> {
  BannerAd? banner;
  InterstitialAd? inter;
  bool bannerReady = false;

  @override
  void initState() { super.initState(); loadBanner(); loadInter(); }

  void loadBanner() {
    banner = BannerAd(
      adUnitId: AppConfig.bannerAd,
      size: AdSize.banner,
      request: const AdRequest(),
      listener: BannerAdListener(onAdLoaded: (_) => setState(() => bannerReady = true), onAdFailedToLoad: (ad, err) => ad.dispose()),
    );
    banner!.load();
  }

  void loadInter() {
    InterstitialAd.load(adUnitId: AppConfig.interAd, request: const AdRequest(), adLoadCallback: InterstitialAdLoadCallback(onAdLoaded: (ad) => inter = ad, onAdFailedToLoad: (_) {}));
  }

  @override
  void dispose() { banner?.dispose(); inter?.dispose(); super.dispose(); }

  Future<void> earnSecurely(String jobId, String link) async {
    try {
      final user = FirebaseAuth.instance.currentUser!;
      final jobRef = FirebaseFirestore.instance.collection('jobs').doc(jobId);
      final userRef = FirebaseFirestore.instance.collection('users').doc(user.uid);
      if (inter!= null) { inter!.show(); loadInter(); }
      if (await canLaunchUrl(Uri.parse(link))) await launchUrl(Uri.parse(link), mode: LaunchMode.externalApplication);
      int earned = 0;
      await FirebaseFirestore.instance.runTransaction((tx) async {
        final jobSnap = await tx.get(jobRef);
        if (!jobSnap.exists) throw Exception('Job not found');
        final reward = (jobSnap.data() as Map)['reward'] as int;
        earned = reward;
        tx.update(userRef, {'wallet': FieldValue.increment(reward)});
      });
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('₦$earned added securely!'), backgroundColor: Colors.green));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e'), backgroundColor: Colors.red));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Amambo TaskHub V18')),
      body: Column(children: [
        StreamBuilder<DocumentSnapshot>(
          stream: FirebaseFirestore.instance.collection('users').doc(FirebaseAuth.instance.currentUser!.uid).snapshots(),
          builder: (c, snap) {
            int wallet = 0;
            if (snap.hasData && snap.data!.exists) wallet = (snap.data!.data() as Map)['wallet']?? 0;
            return Container(width: double.infinity, padding: const EdgeInsets.all(16), color: Colors.green, child: Text('Balance: ₦$wallet', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 22)));
          },
        ),
        Expanded(
          child: StreamBuilder<QuerySnapshot>(
            stream: FirebaseFirestore.instance.collection('jobs').orderBy('createdAt', descending: true).snapshots(),
            builder: (c, snap) {
              if (!snap.hasData) return const Center(child: CircularProgressIndicator());
              if (snap.data!.docs.isEmpty) return const Center(child: Text('No campaigns yet.'));
              return ListView.builder(
                itemCount: snap.data!.docs.length,
                itemBuilder: (c, i) {
                  final doc = snap.data!.docs[i];
                  final data = doc.data() as Map<String, dynamic>;
                  return Card(
                    margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                    child: ListTile(
                      title: Text(data['title']?? ''),
                      subtitle: Text('Reward ₦${data['reward']?? 0}'),
                      trailing: ElevatedButton(onPressed: () => earnSecurely(doc.id, data['link']?? 'https://google.com'), child: const Text('VIEW')),
                    ),
                  );
                },
              );
            },
          ),
        ),
        if (bannerReady && banner!= null) SizedBox(height: 50, child: AdWidget(ad: banner!)),
      ]),
    );
  }
}

class AdvertisePro extends StatefulWidget {
  const AdvertisePro({super.key});
  @override
  State<AdvertisePro> createState() => _AdvertiseProState();
}

class _AdvertiseProState extends State<AdvertisePro> {
  final titleC = TextEditingController();
  final linkC = TextEditingController();
  final bizC = TextEditingController();
  final rewardC = TextEditingController(text: '20');
  final budgetC = TextEditingController(text: '1000');

  Future<void> postAd() async {
    if (titleC.text.trim().isEmpty || linkC.text.trim().isEmpty) return;
    await launchUrl(Uri.parse(AppConfig.paystackAds), mode: LaunchMode.externalApplication);
    await FirebaseFirestore.instance.collection('jobs').add({
      'title': titleC.text.trim(),
      'link': linkC.text.trim(),
      'business': bizC.text.trim(),
      'reward': int.tryParse(rewardC.text)?? 20,
      'budget': int.tryParse(budgetC.text)?? 1000,
      'postedBy': FirebaseAuth.instance.currentUser!.uid,
      'createdAt': FieldValue.serverTimestamp(),
      'status': 'active'
    });
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Campaign LIVE!'), backgroundColor: Colors.green));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Advertise')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          TextField(controller: bizC, decoration: const InputDecoration(labelText: 'Business Name', border: OutlineInputBorder())),
          const SizedBox(height: 10),
          TextField(controller: titleC, decoration: const InputDecoration(labelText: 'Ad Title', border: OutlineInputBorder())),
          const SizedBox(height: 10),
          TextField(controller: linkC, decoration: const InputDecoration(labelText: 'Link https://', border: OutlineInputBorder())),
          const SizedBox(height: 10),
          Row(children: [
            Expanded(child: TextField(controller: rewardC, decoration: const InputDecoration(labelText: 'Reward', border: OutlineInputBorder()))),
            const SizedBox(width: 8),
            Expanded(child: TextField(controller: budgetC, decoration: const InputDecoration(labelText: 'Budget', border: OutlineInputBorder()))),
          ]),
          const SizedBox(height: 16),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.green, foregroundColor: Colors.white, minimumSize: const Size(double.infinity, 56)),
            onPressed: postAd,
            child: const Text('PAY & PUBLISH'),
          ),
        ]),
      ),
    );
  }
}

class VTUPro extends StatefulWidget {
  const VTUPro({super.key});
  @override
  State<VTUPro> createState() => _VTUProState();
}

class _VTUProState extends State<VTUPro> {
  final phoneCtrl = TextEditingController();
  final amountCtrl = TextEditingController(text: '100');
  String netVal = '1';
  final Map<String, String> netList = {'1': 'MTN', '2': 'GLO', '3': '9MOBILE', '4': 'AIRTEL'};
  bool isBusy = false;
  int walletNow = 0;

  @override
  void initState() { super.initState(); fetchWallet(); }

  Future<void> fetchWallet() async {
    final doc = await FirebaseFirestore.instance.collection('users').doc(FirebaseAuth.instance.currentUser!.uid).get();
    if (doc.exists && mounted) setState(() => walletNow = (doc.data() as Map)['wallet']?? 0);
  }

  Future<void> buyAirtimeSecure() async {
    if (phoneCtrl.text.trim().length!= 11) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Phone 11 digits'), backgroundColor: Colors.red));
      return;
    }
    final int amt = int.tryParse(amountCtrl.text.trim())?? 0;
    if (amt < 50 || walletNow < amt) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(amt < 50? 'Min ₦50' : 'Insufficient ₦$walletNow'), backgroundColor: Colors.red));
      return;
    }
    setState(() => isBusy = true);
    try {
      final user = FirebaseAuth.instance.currentUser!;
      final idToken = await user.getIdToken();
      final res = await http.post(Uri.parse(AppConfig.vtuApiUrl), headers: {'Content-Type': 'application/json', 'Authorization': 'Bearer $idToken'}, body: jsonEncode({"network": int.parse(netVal), "amount": amt, "phone": phoneCtrl.text.trim()}));
      if (res.statusCode == 200 || res.statusCode == 201) {
        await FirebaseFirestore.instance.collection('users').doc(user.uid).update({'wallet': FieldValue.increment(-amt)});
        await FirebaseFirestore.instance.collection('vtu_history').add({'userId': user.uid, 'network': netList[netVal], 'phone': phoneCtrl.text.trim(), 'amount': amt, 'createdAt': FieldValue.serverTimestamp()});
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Airtime Sent!'), backgroundColor: Colors.green));
        fetchWallet();
      } else {
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Failed: ${res.body}'), backgroundColor: Colors.red));
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e'), backgroundColor: Colors.red));
    } finally {
      if (mounted) setState(() => isBusy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Buy Airtime')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: Colors.green.shade50, borderRadius: BorderRadius.circular(12)), child: Text('Wallet: ₦$walletNow', style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.green))),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(value: netVal, decoration: const InputDecoration(labelText: 'Network', border: OutlineInputBorder()), items: netList.entries.map((e) => DropdownMenuItem(value: e.key, child: Text(e.value))).toList(), onChanged: (v) => setState(() => netVal = v!)),
          const SizedBox(height: 10),
          TextField(controller: phoneCtrl, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'Phone 080...', border: OutlineInputBorder())),
          const SizedBox(height: 10),
          TextField(controller: amountCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Amount', border: OutlineInputBorder())),
          const SizedBox(height: 16),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.green, foregroundColor: Colors.white, minimumSize: const Size(double.infinity, 54)),
            onPressed: isBusy? null : buyAirtimeSecure,
            child: Text(isBusy? 'PROCESSING...' : 'BUY AIRTIME'),
          ),
        ]),
      ),
    );
  }
}

class ProfilePro extends StatelessWidget {
  const ProfilePro({super.key});
  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    return Scaffold(
      appBar: AppBar(title: const Text('Wallet')),
      body: StreamBuilder<DocumentSnapshot>(
        stream: FirebaseFirestore.instance.collection('users').doc(user!.uid).snapshots(),
        builder: (c, snap) {
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final data = snap.data!.data() as Map<String, dynamic>? ?? {};
          return Padding(
            padding: const EdgeInsets.all(16),
            child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              Card(child: ListTile(title: Text(data['name']?? ''), subtitle: Text(user.email?? ''))),
              const SizedBox(height: 10),
              Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: Colors.green, borderRadius: BorderRadius.circular(12)), child: Column(children: [Text('Balance', style: TextStyle(color: Colors.white70)), Text('₦${data['wallet']?? 0}', style: TextStyle(color: Colors.white, fontSize: 32, fontWeight: FontWeight.w900))])),
              const SizedBox(height: 10),
              ListTile(title: Text('My Referral Code: ${data['myReferralCode']?? ''}'), trailing: IconButton(icon: Icon(Icons.share), onPressed: () => Share.share('Join Amambo TaskHub with my code ${data['myReferralCode']} https://amambotaskhub.com'))),
              const SizedBox(height: 10),
              ElevatedButton(onPressed: () => launchUrl(Uri.parse(AppConfig.paystackDeposit), mode: LaunchMode.externalApplication), child: Text('FUND WALLET')),
              const SizedBox(height: 10),
              OutlinedButton(onPressed: () => FirebaseAuth.instance.signOut(), child: Text('LOGOUT')),
            ]),
          );
        },
      ),
    );
  }
}