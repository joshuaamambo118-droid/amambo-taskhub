import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart' show defaultTargetPlatform, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      default:
        return android;
    }
  }

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyBXovidCLypuxs3FyT4TwHhXVjADSLlHcc',
    appId: '1:1040980101986:android:55c7aa11b287158842ba3b',
    messagingSenderId: '1040980101986',
    projectId: 'amambo-taskhub',
    storageBucket: 'amambo-taskhub.firebasestorage.app',
  );
}